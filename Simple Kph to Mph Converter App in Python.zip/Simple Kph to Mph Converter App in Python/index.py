from tkinter import *

root = Tk()
root.title("Simple Kph to Mph Converter App")
width = 700
height = 200
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width/2) - (width/2) 
y = (screen_height/2) - (height/2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
root.resizable(0, 0)
root.config(bg="white")

def CelciusToFahren():
    MPH.set("")
    if KPH.get() != "":
        MPH.set(0.6214 * float(KPH.get()))
                 
def FahrenToCelcius():
    KPH1.set("")
    if MPH1.get() != "":
        KPH1.set(float(MPH1.get()) * 1.609344)
   

KPH = StringVar()
KPH1= StringVar()
MPH = StringVar()
MPH1 = StringVar()



Top = Frame(root, width=700, bd=1, relief=SOLID)
Top.pack(side=TOP)
BottomTitle = Frame(root, width=700, bd=1, relief=SOLID)
BottomTitle.pack(side=TOP, pady=10)
BottomForm = Frame(root, width=700, bg="white")
BottomForm.pack(side=TOP)
BottomLeft = Frame(BottomForm, width=250, bd=1, relief=SOLID)
BottomLeft.pack(side=LEFT)
BottomRight = Frame(BottomForm, width=250, bd=1, relief=SOLID)
BottomRight.pack(side=RIGHT, padx=10)



lbl_title = Label(Top, text="Converting KPH to MPH", width=700 ,font=('arial', 18))
lbl_title.pack(fill=X)
lbl3 = Label(BottomLeft, text="KPH To MPH",font=('arial', 12))
lbl3.grid(row=0, columnspan=5, column=0)
lbl4 = Label(BottomRight, text="MPH To KPH",font=('arial', 12))
lbl4.grid(row=0, columnspan=5, column=0)
lbl_kph = Label(BottomLeft, text="KPH", font=(12))
lbl_kph.grid(row=1, padx=5, pady=10)
lbl_kph1 = Label(BottomRight, text="KPH", font=(12))
lbl_kph1.grid(row=1, column=3 )
lbl_to2 = Label(BottomLeft, text="-")
lbl_to2.grid(row=1, column=2)
lbl_to3 = Label(BottomRight, text="-")
lbl_to3.grid(row=1, column=2)
lbl_mph = Label(BottomLeft, text="MPH", font=(12))
lbl_mph.grid(row=1, column=3)
lbl_mph1 = Label(BottomRight, text="MPH", font=(12))
lbl_mph1.grid(row=1, padx=5, pady=10)


kph1 = Entry(BottomLeft, textvariable=KPH, width=12)
kph1.grid(row=1, column=1)
kph2 = Entry(BottomRight, textvariable=KPH1, width=12, state=DISABLED)
kph2.grid(row=1, column=4, padx=5)
mph1 = Entry(BottomLeft, textvariable=MPH, width=12, state=DISABLED)
mph1.grid(row=1, column=4, padx=5)
mph2 = Entry(BottomRight, textvariable=MPH1, width=12)
mph2.grid(row=1, column=1)


btn3 = Button(BottomLeft, text="Convert", width=20, bg="white", command=CelciusToFahren)
btn3.grid(row=2, columnspan=5, column=0, pady=10)
btn4 = Button(BottomRight, text="Convert", width=20, bg="white", command=FahrenToCelcius)
btn4.grid(row=2, columnspan=5, column=0, pady=10)


if __name__ == '__main__':
    root.mainloop()
